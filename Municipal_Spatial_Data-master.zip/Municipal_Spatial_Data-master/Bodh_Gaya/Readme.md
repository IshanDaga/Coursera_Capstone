Bodh Gaya Municipal Spatial Data
====

This Repository contains Ward data related to Bodh Gaya.

* Bodh_Gaya_Boundary.geojson

Bodh Gaya Boundary in GeoJSON Format

* Bodh_Gaya_Wards.geojson

Bodh Gaya Ward Boundaries in GeoJSON Format

* Bodh_Gaya_Boundary-SHP.zip

Bodh Gaya Boundary in Shapefile Format

* Bodh Gaya_Wards-SHP.zip

Bodh Gaya Ward Boundaries in Shapefile Format


====

**License**

The dataset is shared under [Creative Commons Attribution-ShareAlike 2.5 India](http://creativecommons.org/licenses/by-sa/2.5/in/) license.