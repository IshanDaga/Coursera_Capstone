Purnia Municipal Spatial Data
====

This Repository contains Ward data related to Purnia.

* Purnia_Boundary.geojson

Purnia Boundary in GeoJSON Format

* Purnia_Wards.geojson

Purnia Ward Boundaries in GeoJSON Format

* Purnia_Boundary-SHP.zip

Purnia Boundary in Shapefile Format

* Purnia_Wards-SHP.zip

Purnia Ward Boundaries in Shapefile Format


====

**License**

The dataset is shared under [Creative Commons Attribution-ShareAlike 2.5 India](http://creativecommons.org/licenses/by-sa/2.5/in/) license.