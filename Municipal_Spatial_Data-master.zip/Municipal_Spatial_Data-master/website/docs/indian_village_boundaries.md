<script>
window.location.href="http://projects.datameet.org/indian_village_boundaries/";
</script>