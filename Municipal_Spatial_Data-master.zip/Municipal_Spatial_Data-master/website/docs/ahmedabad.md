## Ahmedabad

## Availabe Maps

- AMC Facilities.kml
- Library.geojson
- Municipal_gyms.geojson
- Swimming_pools.geojson
- Ward_office.geojson
- Wards.geojson	
- Zonal_office.geojson


## Download
Download from github
<a class="btn btn-lg btn-success" href="https://github.com/datameet/Municipal_Spatial_Data/tree/master/Ahmedabad">
<i class="fa fa-github fa-2x pull-left"></i> GitHub</a>   


Go to the full map file and then look for Download link or Raw


## Issues

If you have any issues with the maps, please report them on the github repository:

<a href="https://github.com/datameet/Municipal_Spatial_Data/issues/new"><button class="btn btn-primary" type="submit">Report Issue</button></a>
<a href="https://github.com/datameet/Municipal_Spatial_Data/issues"><button class="btn btn-primary" type="submit">Active Issues</button></a>

