<script>
window.location.href="http://projects.datameet.org/maps/assembly-constituencies/";
</script>