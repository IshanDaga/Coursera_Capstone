<script>
window.location.href="http://projects.datameet.org/Municipal_Spatial_Data/";
</script>