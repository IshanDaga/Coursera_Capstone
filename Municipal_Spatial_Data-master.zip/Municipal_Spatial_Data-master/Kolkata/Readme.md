# Kolkata Municipal Data

This Repository contains

1. Ward of the Kolkata Municipal Corporation (Source: shared by [Justin](https://github.com/justinelliotmeyers) in this [datameet](https://groups.google.com/d/msg/datameet/k7Hp9jEDRTk/H66HNdNiBAAJ) thread)

---

**License**

The dataset is created by the Pune chapter of the DataMeet Trust, Bangalore, India, and is shared under [Creative Commons Attribution-ShareAlike 2.5 India](http://creativecommons.org/licenses/by-sa/2.5/in/) license.
