Bhubaneswar Municipal Corporation Data
====

This Repository contains data related to the Bhubaneswar Municipal Corporation.

* BDA_Boundary

This Is the Boundary of the Bhubaneswar Development Authority

* BMC Boundary

 This is the Boundary of Bhubaneswar Municipal Corporation.

* Wards

	This is the Ward Boundary of Bhubaneswar Municipal Corporation.

* Police_Jurisdiction

Boundries of the Police Jurisdiction


This Data was scraped from http://www.bhubaneswarone.in/home/index.html



====

**License**

The dataset is shared under [Creative Commons Attribution-ShareAlike 2.5 India](http://creativecommons.org/licenses/by-sa/2.5/in/) license.