Chandigarh Municipal Spatial Data
====

This Repository contains Ward data related to Chandigarh.

* Chandigarh_Boundary.geojson

Chandigarh Boundary in GeoJSON Format

* Chandigarh_Sectors.geojson

Chandigarh Sector Boundaries in GeoJSON Format

* Chandigarh_Wards.geojson

Chandigarh Ward Boundaries in GeoJSON Format

* Chandigarh_Boundary-SHP.zip

Chandigarh Boundary in Shapefile Format

* Chandigarh_Sectors-SHP.zip

Chandigarh Sector Boundaries in Shapefile Format

* Chandigarh_Wards-SHP.zip

Chandigarh Ward Boundaries in Shapefile Format


====

**License**

The dataset is shared under [Creative Commons Attribution-ShareAlike 2.5 India](http://creativecommons.org/licenses/by-sa/2.5/in/) license.