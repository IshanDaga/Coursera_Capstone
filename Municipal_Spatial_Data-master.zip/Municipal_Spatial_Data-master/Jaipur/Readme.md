Jaipur Municipal Spatial Data
====

This Repository contains Ward data related to Jaipur.

* Jaipur_Assembly_constituency.geojson

Jaipur Assembly constituency Boundaries in GeoJSON Format

* Jaipur_Boundary.geojson

Jaipur Boundary in GeoJSON Format

* Jaipur_Wards.geojson

Jaipur Ward Boundaries in GeoJSON Format

* Jaipur_Zones.geojson

Jaipur Municipal Zones Boundaries in GeoJSON Format

* Jaipur_Assembly_constituency-SHP.zip

Jaipur Assembly constituency Boundaries in Shapefile Format

* Jaipur_Boundary-SHP.zip

Jaipur Boundary in Shapefile Format

* Jaipur_Wards-SHP.zip

Jaipur Ward Boundaries in Shapefile Format

* Jaipur_Zones-SHP.zip

Jaipur Municipal Zones Boundaries in Shapefile Format

====

**License**

The dataset is shared under [Creative Commons Attribution-ShareAlike 2.5 India](http://creativecommons.org/licenses/by-sa/2.5/in/) license.