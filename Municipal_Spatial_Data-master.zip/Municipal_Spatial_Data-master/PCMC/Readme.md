Pune Municipal Data
====

This Repository contains Ward data related to the Pimpri & Chinchwad Municipal Corporation.

* pcmc-electoral-wards.geojson 
Pimpri Chinchwad's electoral wards.
Source: http://shelter-associates.org/spatial-slum-information (scraped)

This data is also present on the [DataMeet's Pune Repository](https://github.com/datameet/Pune_wards)

====

**License**

The dataset is created by the Pune chapter of the DataMeet Trust, Bangalore, India, and is shared under [Creative Commons Attribution-ShareAlike 2.5 India](http://creativecommons.org/licenses/by-sa/2.5/in/) license.