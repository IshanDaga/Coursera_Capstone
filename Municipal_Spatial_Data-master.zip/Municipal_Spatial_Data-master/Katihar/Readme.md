Katihar Municipal Spatial Data
====

This Repository contains Ward data related to Katihar.

* Katihar_Boundary.geojson

Katihar Boundary in GeoJSON Format

* Katihar_Wards.geojson

Katihar Ward Boundaries in GeoJSON Format

* Katihar_Boundary-SHP.zip

Katihar Boundary in Shapefile Format

* Katihar_Wards-SHP.zip

Katihar Ward Boundaries in Shapefile Format


====

**License**

The dataset is shared under [Creative Commons Attribution-ShareAlike 2.5 India](http://creativecommons.org/licenses/by-sa/2.5/in/) license.