MMR Boundary
====

This Repository contains the Boundary of the MMR.

MMR, or the Mumbai Metropolitan Region isn't a Municpal corporation, but the [MMRDA](https://mmrda.maharashtra.gov.in/), which works on this region, has a huge budget, and lots of development Activity happens in this region, funded by the Central Government, Maharastra Government, as well as directly.

As per the MMRDA website it is spread over 4,355 sq. km. and consists of 8 Municipal Corporations viz. Greater Mumbai, Thane, Kalyan-Dombivali, Navi Mumbai, Ulhasnagar, Bhiwandi- Nizamapur, Vasai-Virar and Mira-Bhayandar; and 9 Municipal Councils viz. Ambarnath, Kulgaon-Badalapur, Matheran, Karjat, Panvel, Khopoli, Pen, Uran, and Alibaug, along with more than 1,000 villages in Thane and Raigad Districts.


This data was digitized from the following report: http://124.7.71.27:8080/documents/10180/49118/Planning_RP/96640a4d-08b0-46e3-866a-1ac26984ff27

====

**License**

The dataset is shared under [Creative Commons Attribution-ShareAlike 2.5 India](http://creativecommons.org/licenses/by-sa/2.5/in/) license.