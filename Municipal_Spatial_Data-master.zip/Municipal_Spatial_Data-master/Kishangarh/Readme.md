Kishangarh Municipal Spatial Data
====

This Repository contains Ward data related to Kishangarh.

* Kishangarh_Boundary.geojson

Kishangarh Boundary in GeoJSON Format

* Kishangarh_Wards.geojson

Kishangarh Ward Boundaries in GeoJSON Format

* Kishangarh_Boundary-SHP.zip

Kishangarh Boundary in Shapefile Format

* Kishangarh_Wards-SHP.zip

Kishangarh Ward Boundaries in Shapefile Format

====

**Source**

This data was Digitised from a Hardcopy of ward map and ward Scripts taken from Kishangarh Municipal Council.

====

**License**

The dataset is shared under [Creative Commons Attribution-ShareAlike 2.5 India](http://creativecommons.org/licenses/by-sa/2.5/in/) license.