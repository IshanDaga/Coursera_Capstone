Vijayawada Municipal Spatial Data
====

This Repository contains Ward data related to Vijayawada.

* Vijayawada_Boundary.geojson

Vijayawada Boundary in GeoJSON Format

* Vijayawada_Wards.geojson

Vijayawada Ward Boundaries in GeoJSON Format

* Vijayawada_Boundary-SHP.zip

Vijayawada Boundary in Shapefile Format

* Vijayawada_Wards-SHP.zip

Vijayawada Ward Boundaries in Shapefile Format

====

**License**

The dataset is shared under [Creative Commons Attribution-ShareAlike 2.5 India](http://creativecommons.org/licenses/by-sa/2.5/in/) license.