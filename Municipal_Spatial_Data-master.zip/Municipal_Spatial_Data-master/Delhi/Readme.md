Delhi Municipal Spatial Data
====

This Repository contains Ward data related to Delhi.

* Delhi_Boundary.geojson

Delhi Boundary in GeoJSON Format

* Delhi_Wards.geojson

Delhi Ward Boundaries in GeoJSON Format

* Delhi_Boundary-SHP.zip

Delhi Boundary in Shapefile Format

* Delhi_Wards-SHP.zip

Delhi Ward Boundaries in Shapefile Format

====

**Source**

This data was scraped from an Arcgis Online Map at [http://www.arcgis.com/home/item.html?id=7c4f1b9be6cc4cecbcd28ee5136898f7](http://www.arcgis.com/home/item.html?id=7c4f1b9be6cc4cecbcd28ee5136898f7)

====

**License**

The dataset is shared under [Creative Commons Attribution-ShareAlike 2.5 India](http://creativecommons.org/licenses/by-sa/2.5/in/) license.