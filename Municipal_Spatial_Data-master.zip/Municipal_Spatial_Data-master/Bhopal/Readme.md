Bhopal Municipal Spatial Data
==

This Repository contains Ward data related to Bhopal.

The following dataset was liberated from a a Google Map  present on the Bhopal Municipal Corporation Website at [http://www.bhopalmunicipal.com/city-information/informative-map.html](http://www.bhopalmunicipal.com/city-information/informative-map.html)
* Bhopal_wards.geojson
Wards in GeoJSON Format
* Ward Map of Bhopal.kml
Wards in KML (Google Earth) Format

The Following datasets were scraped from https://smartmapbhopal.city/bhopalsmartmap/

* Planning_ Boundary_ 2031.geojson
* Ward_Offices.geojson
* Zone_Boundary.geojson
* Zone_Offices.geojson
* 


----------

**License**

The dataset is shared under [Creative Commons Attribution-ShareAlike 2.5 India](http://creativecommons.org/licenses/by-sa/2.5/in/) license.