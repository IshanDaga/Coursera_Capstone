Faridabad Municipal Spatial Data
====

This Repository contains Ward data related to Faridabad.

* Faridabad_Boundary.shp.geojson

Faridabad Boundary in GeoJSON Format

* Faridabad_Wards.geojson

Faridabad Ward Boundaries in GeoJSON Format

* Faridabad_Boundary-SHP.zip

Faridabad Boundary in Shapefile Format

* Faridabad_Wards-SHP.zip

Faridabad Ward Boundaries in Shapefile Format

* Faridabad_Wards.kml

Faridabad Ward Boundaries in KML Format


====

**License**

The dataset is shared under [Creative Commons Attribution-ShareAlike 2.5 India](http://creativecommons.org/licenses/by-sa/2.5/in/) license.