Coimbatore Municipal Data
====


The files

1. Cbe2011Wards.geojson contains the ward map of Coimbatore reorganized 
   (100 wards)
2. CbeCensus2011Wards.geojson contains the ward map of Coimbatore as per
   the Census of India 2011 (72 wards), this is georefenced from a web image
   the accuracy of geometry is low


====

**License**

The dataset is shared under [Creative Commons Attribution-ShareAlike 2.5 India](http://creativecommons.org/licenses/by-sa/2.5/in/) license.
