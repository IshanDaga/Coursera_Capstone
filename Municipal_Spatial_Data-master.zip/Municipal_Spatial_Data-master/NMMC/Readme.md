Navi Mumbai Municipal Data
====

This Repository contains data related to the Navi Mumbai Municipal Corporation.

* NMMCElection_final_ward 18032015.kml 

* NMC_ElectoralWards.geojson


Navi Mumbai's electoral wards. Source: http://www.nmmconline.com/ward-map





====

**License**

The dataset is shared under [Creative Commons Attribution-ShareAlike 2.5 India](http://creativecommons.org/licenses/by-sa/2.5/in/) license.