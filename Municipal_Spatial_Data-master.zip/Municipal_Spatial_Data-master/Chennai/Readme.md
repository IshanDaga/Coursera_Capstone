Chennai Municipal Data
====

This Repository contains Municipal data related to Chennai.

This Data was received from the [Transparent Chennai](http://www.transparentchennai.com/) team.



* cma
Chennai Metropolitan Area 

* Wards
electoral wards for Chennai city

* Zones
zones in Chennai city

====

**License**

The dataset is shared under [Creative Commons Attribution-ShareAlike 2.5 India](http://creativecommons.org/licenses/by-sa/2.5/in/) license.