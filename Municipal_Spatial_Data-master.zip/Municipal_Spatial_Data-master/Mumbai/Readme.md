Mumbai Municipal Data
====

This Repository contains 

1. Ward of the Brihanmumbai Municipal Corporation (BMC) also known as Municipal Corporation of Greater Mumbai.
1. Slum clusters map extracted from [http://www.sra.gov.in/upload/MUMABI_CA_MAP_MUMBAI_GLOBAL_42X72_SLUMCLUSTER.pdf]


====

**License**

The dataset is created by the Pune chapter of the DataMeet Trust, Bangalore, India, and is shared under [Creative Commons Attribution-ShareAlike 2.5 India](http://creativecommons.org/licenses/by-sa/2.5/in/) license.
